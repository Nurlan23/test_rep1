.. _tutorial-index:

###########################
  The sx Tutorial
###########################

Welcome to the online version of The sx Tutorial, a free tutorial about
the sx tools for the Bitcoin cryptocurrency.

.. toctree::
   :numbered:

   introduction
   quickstart
   offlinetx
   qrcode
   detwallet
   history
   multisig

Authors
=======

Amir Taaki (genjix) - Development - 1Fufjpf9RM2aQsGedhSpbSCGRHrmLMJ7yY

Santiago Mendez (d3) - Feedback, heavy testing and improvements.

Vitalik Buterin - Development - 1GNRekXGy7s2UYnE7ZhMcWdv3GpJSGtLkc

