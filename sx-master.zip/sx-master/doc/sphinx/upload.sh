scp -r _build/html/* genjix@munir.dyne.org:www/subx/

