.. _tut-qrcode:

*****************
QR Code Generator
*****************

::

    $ sudo apt-get install qrencode
    $ sx qrcode 13Ft7SkreJY9D823NPm4t6D1cBqLYTJtAe qrcode.png

